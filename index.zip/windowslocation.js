document.getElementById("test").innerHTML = 
							""+ window.location.href;